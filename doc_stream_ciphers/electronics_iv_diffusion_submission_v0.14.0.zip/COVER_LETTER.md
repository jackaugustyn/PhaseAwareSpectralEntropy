29 October 2026

Dear Editors of Electronics,

Please consider the manuscript “Block-Position Structure in Reduced ChaCha20 and Salsa20: Experimental Diagnostics of IV Diffusion” for publication as an Article in Electronics.

The study examines how changes in a public nonce propagate through the emitted output of two ARX stream ciphers. Its contribution is an experimental characterization of reduced-core diffusion: a repeated four-position response within two-round output blocks, a controlled intervention that tests dependence on measurement order, and a separate complete nonce-bit scan that resolves nonce-word asymmetry. This focus on the analysis of cryptographic components used in secure communication motivates submission to Electronics.

Both ChaCha20/2 and Salsa20/2 exhibit the positional structure. Rotating measurements independently within output blocks preserves their Hamming-weight values and DC power share, yet reduces the AC entropy contrast by approximately 96% and 94%, respectively. A fresh cohort covering all 64 shared nonce-bit positions confirms a +0.79059-bit second-minus-first nonce-word entropy gap in Salsa20/2 (95% CI [0.78404, 0.79729]; Holm-adjusted p = 2 × 10⁻⁵). ChaCha20/2 instead has a near-zero aggregate entropy gap alongside compensating output-word Hamming-weight responses.

The manuscript compares spectral and direct diagnostics on identical streams and states their respective roles. Simple avalanche and correlation statistics already detect the large two-round deviations; spectral decomposition and alignment controls help explain their structure. The work does not claim a full-round vulnerability, a key-recovery attack, or superior detector sensitivity. Complementary initialization and A5/1 experiments are retained in appendices to document the limits of the diagnostic.

A versioned reviewer archive provides fixed protocols, raw arrays, analysis code, cipher-vector checks, and checksums. Its planned tests and descriptive analyses are distinguished throughout the manuscript. Public deposition has not yet been completed, and the data-availability statement reflects that status.

Sincerely,

Paweł Augustynowicz  
Faculty of Cybernetics, Military University of Technology  
Warsaw, Poland  
pawel.augustynowicz@wat.edu.pl

---

Draft for author review. Before using the letter, confirm the manuscript's publication and concurrent-submission status and add any declarations required by the current journal instructions. These statements have not been inferred on the author's behalf.
