# IV-Diffusion Diagnostics: Electronics article and reproducibility package

This folder contains the complete manuscript, the figure used in it, the
processed tables and raw arrays behind its results, fixed study protocols,
source code, and cipher-vector checks for **Block-Position Structure in Reduced
ChaCha20 and Salsa20: Experimental Diagnostics of IV Diffusion**, prepared for
MDPI *Electronics*. The article presents an experimental cryptographic analysis
of nonce diffusion, using direct and spectral diagnostics to localize the
response of two reduced ARX cores. The wider seven-cipher comparison and
Grain-128, Trivium, and A5/1 follow-ups provide supporting evidence and scope
checks in the appendices. This is a local draft for author review; no public
DOI is assigned yet.

The main results are the recurring four-position response in ChaCha20/2 and
Salsa20/2, an independently confirmed +0.79059-bit second-minus-first nonce-word
spectral-entropy gap in Salsa20/2 (Holm-adjusted p = 0.00002), and paired rotations
that remove about 96% and 94% of the respective normalized AC-entropy contrasts.
Direct Hamming-weight and avalanche measures also detect the large two-round
deficits. Spectral decomposition helps explain their organization; these
experiments establish neither detector superiority nor a full-round weakness.

Version 0.15.0 adds an operation-graph and feed-forward explanation, a
descriptive reanalysis at 32-, 64-, and 128-bit segment widths, and a completed
independent validation on 80 new key pairs (indices 840–919). The new cohort
covers all 64 nonce bits and 8192 output bits at two and four rounds. Five
predictions fixed before generation are confirmed: Salsa20/2 has a positive
nonce-word entropy gap at all three widths, while ChaCha20/2 has a positive
32-bit gap and a negative 64-bit gap. Each planned test has five-test
Holm-adjusted p approximately 0.00005. The small 128-bit ChaCha20 aggregate
must therefore not be interpreted as universal nonce-word symmetry. Exact
Salsa20 unchanged-word, feed-forward and counter-independence checks have
zero violations on the fresh cohort.

## Start here

Run these commands **from this folder**:

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py verify
.venv/bin/python run.py build
```

`verify` checks published cipher vectors, the nonce mapping and rotation
invariants, archived raw arrays, statistical summaries, and SHA-256 digests,
including the independent audit of the mechanism, resolution reanalysis and
fresh validation. To run just that audit, use
`python3 tools/audit_arx_extensions.py`.
It does not regenerate the computationally expensive cohorts. `build`
regenerates the article figure and compiles `doc_stream_ciphers/main.pdf`.
Building the PDF requires `latexmk`, `pdflatex`, and `bibtex` in addition to
Python. The MDPI class and bibliography inputs are included in this folder.

The code requires Python 3.10 or newer. `run.py` sets `PYTHONPATH` for child
scripts, so the commands above work without installing this repository as a
package. On systems without `venv`, use a Python environment with the packages
listed in `requirements.txt`. Generation and analysis manifests record the
Python and NumPy versions used; the reviewer archive records the installed
package versions when it is built.

## What's inside

| Path | Purpose |
| --- | --- |
| `doc_stream_ciphers/main.tex`, `main.pdf`, `biblio.bib`, `Definitions/` | Main MDPI source, compiled copy, references, and template. |
| `doc_stream_ciphers/related_work_comparison.tex`, `arx_mechanism.tex`, `arx_resolution_methods.tex`, `arx_resolution_results.tex` | Four required source files included by the main manuscript. |
| `doc_stream_ciphers/publication_unified_mask_followup.pdf` | Figure included in the article. |
| `doc_stream_ciphers/COVER_LETTER.md`, `doc_stream_ciphers/ELECTRONICS_REVISION.md` | Draft cover letter and record of the Electronics revision. |
| `doc_stream_ciphers/RESEARCH_EXTENSION_STATUS.md`, `RELATED_WORK_NOTES.md`, `ARX_MECHANISM_NOTES.md` | Extension status, scope of literature verification, and mechanistic evidence. |
| `doc_stream_ciphers/data/`, `doc_stream_ciphers/analysis/mask_scan_results/` | Raw `.npz` arrays, per-key values, summary tables, planned tests, and manifests. |
| `doc_stream_ciphers/*PROTOCOL.txt`, `SAME_DATA_DIAGNOSTIC_BENCHMARK.txt` | Unchanged text of the locked designs and same-stream comparison plan. |
| `experiments/stream_rounds_study/` | Cipher generation, measurement, statistical analyses, and read-only audits. |
| `src/spectral_crypto_analyzer/` | Reused cipher cores required by the study. |
| `tests/`, `tools/check_vectors.py`, `tools/audit_arx_extensions.py` | Published vectors, numerical invariants, and independent audits. The tests use the dependencies in `requirements.txt`. |
| `PACKAGE_MANIFEST.json`, `verify_package.py` | SHA-256 inventory of this folder. |

The article's common measurement definition is 32 consecutive 128-bit HW
values from 4096 output bits per fixed-key IV pair. The six-cipher and Salsa20
cohorts use the same estimator but have separate planned-test families. The
matched-nonce phase intervention, 64-mask study, Grain/Trivium follow-ups,
and A5/1 frame screen each have their own protocol and inference limits.
The resolution extension aggregates stored 32-bit word HW into three segment
widths. Its fresh cohort doubles the stream length to 8192 bits; the original
raw arrays and their locked protocols are preserved unchanged.

The focused numerical tests can be run with
`python3 -m pytest -q tests/test_arx_resolution.py tests/test_arx_resolution_validation.py`.
Pytest is included in the requirements. These tests check aggregation against
bit-level differences, frequency indexing, and the sign-flip/Holm calculations.

## Cohorts and data

| Cohort | Keys | Main files and inference |
| --- | --- | --- |
| Six-cipher ordinary IV/nonce | 80 per cipher | `data/unified_six_results/`: six raw HW arrays, per-key/summary CSVs, six standard and three fresh-key planned endpoints. |
| Salsa20 transfer | 80 new keys | `data/salsa20_transfer_results/`: one raw array, phase rows, and a separate three-test family. |
| Matched-nonce phase rotation | 80 paired key indices | `data/matched_nonce_phase_results/`: two raw HW arrays, 128 paired rotation schedules per cell, and two planned alignment tests. |
| Same-stream comparison | Same matched-nonce keys | `data/same_data_benchmark_results/`: bitwise counts and direct/spectral scores on identical output streams; descriptive. |
| Full-mask and locality follow-up | 80 fresh ARX keys plus 80 Grain/Trivium keys | `data/literature_mask_followup/`: all 64 nonce bits, 32-bit output-word HW, Grain IV positions, Trivium subcubes; two planned ARX tests, one Grain validation, and a 12-cell Trivium pilot. |
| A5/1 frame screen and validation | 80 + 80 separate keys | `data/a51_frame_followup/`: raw 114-bit frame XORs, corrected 44-cell standard-depth search, and independent zero-clock gradient validation. |
| Earlier exploratory mask scan | Earlier keys | `analysis/mask_scan_results/`: retrospective per-mask profiles and descriptive comparisons. |
| ARX mechanism analysis | Existing 520–599 cohort | `data/arx_mechanism_results/`: operation dependencies, feed-forward checks, observed word profiles and counter-independent words; descriptive and algebraic checks. |
| Archived ARX resolution/window reanalysis | Same 80 key pairs, 520–599 | `data/arx_resolution_results/`: 32/64/128-bit segments and full4096/first2048/last2048 windows; descriptive, no new keys. |
| Independent ARX resolution validation | 80 fresh key pairs, 840–919 | `data/arx_resolution_validation/`: 8192 bits, all 64 masks, 2/4 rounds, five planned two-round tests, descriptive window checks, exact structural checks and resumable checkpoints. |

The raw experiment `.npz` files contain `observed`/`actual` and matched
`control`/`oracle` arrays plus cohort indices. The six-cipher and Salsa20
common arrays have axes
key × configuration × mask family × 16 IV pairs × 32 output segments. The
full-mask ARX array retains key × cipher × rounds × 64 nonce bits × four
base nonces × eight output blocks × 16 output words. The A5/1 screen stores
key × warm-up depth × 22 frame masks × four bases × 15 packed bytes; only the
first 114 bits are used. The full-mask per-mask estimator averages four
trajectories and is numerically distinct from the common 16-pair estimator.
The new validation array has axes key × two ciphers × two round counts ×
64 masks × four base nonces × 16 output blocks × 16 word HW values. Its
full8192/first4096/last4096 analyses average the four base-nonce Fourier power
vectors within each mask before normalization. Block-harmonic power and the
512-bit fundamental are reported separately: power at harmonics alone does
not establish a fundamental period.

The data manifests record cohort ranges, fixed protocols, raw-array hashes,
and planned-test families. Whole keys, not individual masks or output blocks,
are the uncertainty unit. Pointwise intervals are not simultaneous bands.

## Reading the source code

```text
fixed key index + protocol -> cipher/control streams -> paired-IV XORs
-> 32-bit word Hamming weights -> 32/64/128-bit segment scores
-> whole-key intervals and corrected tests -> tables -> figure -> article
```

Start with these functions; their docstrings explain inputs and outputs:

| Function | What it does |
| --- | --- |
| `unified_six_cipher_iv_study._pairs_by_scenario` | Builds the shared IV-pair graph and rejects collisions. |
| `unified_six_cipher_iv_study._oracle_stream` | Assigns one SHAKE256 control stream to each IV vertex, preserving reuse across masks. |
| `unified_six_cipher_iv_study._one_key` | Measures all settings and masks for one independent cipher key. |
| `unified_six_cipher_iv_study._attribution` | Splits an `H_MP` difference into exact symmetric DC and AC contributions. |
| `salsa20_transfer_study._one_key` | Repeats the common estimator for the separate Salsa20 key cohort. |
| `matched_nonce_phase_study._rotated`, `_measure` | Rotates positions inside 512-bit blocks and compares spectra while preserving DC share. |
| `same_data_diagnostic_benchmark._scores` | Compares spectral entropy with direct HW, avalanche, lag-four, and phase scores on the same streams. |
| `literature_mask_followup._arx_one`, `_trivium_one`, `_grain_one` | Generate the independent nonce-mask and IV-locality raw arrays. |
| `analyze_literature_mask_followup._arx`, `_trivium`, `_grain` | Rebuild the corrected planned tests and descriptive profiles. |
| `a51_frame_followup._one`, `analyze_a51_frame_followup._metrics` | Generate frame XORs and measure 114-bit frame responses. |
| `arx_mechanism_analysis` | Follows the two-round operation graph, checks the emitted-output construction and relates it to archived word profiles. |
| `analyze_arx_resolution.aggregate_words`, `measure` | Reaggregate archived word HW and measure full-spectrum, AC, harmonic and fundamental power summaries. |
| `arx_resolution_validation.generate_one`, `analyze` | Generate or resume the independently fixed 80-key-pair cohort and report its five planned tests plus descriptive results. |

The common `_key_material` helper lives in `publication_study.py`; the
`_mask_sets`, `_metrics`, and `_block_hamming_weights` helpers live in
`standard_iv_validation.py`. The main cipher cores are in
`extension_stream_cores.py` and `src/spectral_crypto_analyzer/primitives.py`.
These two helper modules and the primitive library also contain historical
experiments outside this article. The published vector checks cover Grain-128,
Trivium, MICKEY 2.0, HC-128, Rabbit, ChaCha20, Salsa20, and A5/1, including
independent reference translations and the ChaCha nonce-layout mapping.

`H_MP` is full-spectrum entropy in bits. In the 32-segment main study,
`H_noDC` is normalized after DC removal. The separate 19-sample A5/1 frame
analogue has another scale. DC/AC attribution returns contributions in bits
to an `H_MP` contrast; it does not convert normalized `H_noDC` to bits.

## Run individual analyses

Set imports once in a shell started from this folder:

```bash
export PYTHONPATH="$PWD/src:$PWD/experiments/stream_rounds_study"
```

The following commands inspect archived results without replacing raw data:

```bash
python3 run.py vectors
python3 run.py audits
python3 tools/audit_arx_extensions.py
python3 verify_package.py
```

To regenerate processed tables from archived raw arrays, run:

```bash
python3 experiments/stream_rounds_study/analyze_literature_mask_followup.py
python3 experiments/stream_rounds_study/analyze_a51_frame_followup.py
python3 experiments/stream_rounds_study/analyze_mask_profiles.py
python3 experiments/stream_rounds_study/arx_mechanism_analysis.py
python3 experiments/stream_rounds_study/analyze_arx_resolution.py
python3 experiments/stream_rounds_study/arx_resolution_validation.py --analyze-only
```

These analysis commands write their CSV/JSON outputs in the corresponding
`doc_stream_ciphers/data/` or `analysis/` directory. Their random resampling
seeds are fixed in source. After an intentional rebuild, refresh the folder
manifest with `python3 verify_package.py --write`.

The independent validation is already complete. Its generator supports
resumption from the included 80 per-key checkpoints and refuses to mix
different protocol, source, cohort or software fingerprints. To check the
separate smoke cohort, or resume the fixed full cohort, use:

```bash
python3 experiments/stream_rounds_study/arx_resolution_validation.py --smoke
python3 experiments/stream_rounds_study/arx_resolution_validation.py
```

The smoke indices 920–921 write only under `/tmp`. The full cohort is
840–919 and writes only to `data/arx_resolution_validation/`; neither command
replaces the earlier ARX raw data. The fixed protocol is
`doc_stream_ciphers/ARX_RESOLUTION_VALIDATION_PROTOCOL.txt` with SHA-256
`01421b276761aa61f8ab69b1339e83c8a5492615d5fa5f3d632e844295a7032b`.
It is a locally fixed follow-up protocol, not a public preregistration.

To regenerate the **raw experiments**, use the commands below in the listed
order. They overwrite archived outputs and may require substantial CPU time
and memory; the included raw arrays already support all article results.

```bash
python3 experiments/stream_rounds_study/unified_six_cipher_iv_study.py
python3 experiments/stream_rounds_study/salsa20_transfer_study.py
python3 experiments/stream_rounds_study/matched_nonce_phase_study.py
python3 experiments/stream_rounds_study/same_data_diagnostic_benchmark.py
python3 experiments/stream_rounds_study/literature_mask_followup.py
python3 experiments/stream_rounds_study/analyze_literature_mask_followup.py
python3 experiments/stream_rounds_study/a51_frame_followup.py
python3 experiments/stream_rounds_study/analyze_a51_frame_followup.py
python3 experiments/stream_rounds_study/a51_loading_validation.py
```

The mask and A5/1 generators support quick two-key trials that write to `/tmp`:

```bash
python3 experiments/stream_rounds_study/literature_mask_followup.py --section grain --smoke --workers 2
python3 experiments/stream_rounds_study/a51_frame_followup.py --smoke --workers 2
```

These trials check execution, not the article's statistical results. For the
figure alone, run `python3 doc_stream_ciphers/make_integrated_mask_figure.py`.
For the paper alone, run `cd doc_stream_ciphers && latexmk -pdf main.tex`.

## Submission and integrity

`python3 run.py package` creates a compact MDPI submission ZIP and a separate
reviewer data/code ZIP under `doc_stream_ciphers/`, verifies their contents,
and refreshes `PACKAGE_MANIFEST.json`. The reviewer ZIP contains protocols,
raw arrays, code, tests, checksums, and the revision record. The submission ZIP contains the
manuscript source, compiled PDF, bibliography, MDPI template, and article
figure, together with the draft cover letter. Both are convenience outputs;
this folder is the readable source. The current archive names are
`electronics_iv_diffusion_submission_v0.15.0.zip` and
`iv_diffusion_research_review_v0.15.0.zip`; the latter has a matching
`iv_diffusion_research_review_v0.15.0_manifest.json`. Earlier v0.13.1 and v0.14.0 archives
remain available as historical versions.

Version 0.15.0 extends the *Electronics* manuscript with the mechanistic
analysis, resolution checks and completed independent validation described
above. The three new result directories preserve provenance separately from
the unchanged earlier raw arrays and protocols. The reviewer archive includes
the new scripts, invariant tests, independent audit and all 80 validation
checkpoints. The submission archive includes all four additional LaTeX source
files needed to compile the main manuscript. The data manifests retain
raw-array, source and protocol hashes;
`PACKAGE_MANIFEST.json` records the current folder. In the extracted reviewer
archive, the same verification command reads its included `SHA256SUMS.json`.

The related-work comparison uses the studies already cited in the manuscript.
An attempt to retrieve primary sources failed because of DNS resolution and
an unavailable automatic approval-review service. A comprehensive current
online literature review was therefore not completed; no first-ever claim
is made for the underlying cipher dependencies. `RELATED_WORK_NOTES.md`
records the exact verification scope and remaining source checks.

Before public submission, the author should verify the title, affiliation,
funding, declarations, figures, citations, and page order in `main.pdf`;
choose a public code/data license; deposit the reviewer ZIP with the draft
metadata in `doc_stream_ciphers/DEPOSIT_METADATA_DRAFT.json`; then insert the
assigned DOI in `main.tex` and rebuild the PDF and ZIPs. The compact
submission ZIP is prepared for *Electronics*; the reviewer ZIP is the
data/code record for Zenodo. No DOI or license has been inserted on the
author's behalf.
