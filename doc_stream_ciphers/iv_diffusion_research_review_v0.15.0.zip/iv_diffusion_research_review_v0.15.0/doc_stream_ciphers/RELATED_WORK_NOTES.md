# Literature-positioning revision and verification scope

Revision date: 2026-10-29.

`related_work_comparison.tex` is a manuscript-ready comparison using **only
references already present in `biblio.bib`**. It distinguishes the experiment
from specifications, avalanche criteria, chosen-IV analyses, and the cited
PNB-based Salsa20/ChaCha study. It is a positioning comparison, not a completed
systematic review of the nearest literature through 2026.

## What was checked locally

- The exact entries for `nir2018`, `bernstein2008salsa`, `webster1986`,
  `hernandez2005`, `englund2007`, `fischer2008`, and `ghafoori2023` are already
  in the repository bibliography. The new table uses their established scope
  conservatively and adds no round limits or attack complexities.
- The manuscript already distinguishes emitted keystream from the
  internal-state observables of `ghafoori2023`.
- `MASK_LITERATURE_FOLLOWUP_PROTOCOL.txt`, lines 39--43 in the pre-existing
  file, records Ghafoori et al. Tables 9 and 17 as the sources of Salsa20
  `x_7[0]` and ChaCha `x_14[6]`, `x_15[6]`. It describes internal bits at four
  or 3.5 rounds. This is an existing repository provenance record, **not a
  fresh independent examination of those tables**. The comparison deliberately
  avoids repeating these exact external claims as newly verified facts.
- No copies of the primary Salsa20/ChaCha articles were found among the
  available local documents. No new bibliographic entries were added because
  their source contents could not be checked.

## External verification attempted

The first public read-only request was for Bernstein's ChaCha paper at
`https://cr.yp.to/chacha/chacha-20080128.pdf`. The sandbox request returned
`curl: (6) Could not resolve host: cr.yp.to`.

The permitted escalation route was then attempted. The automatic approval
review service returned HTTP 404 for its own deployment and did not execute
the request. Its message explicitly identified this as failure to complete
the review, not a determination that the download was unsafe. No approval
check was bypassed. Consequently there is no newly downloaded source and no
claim of current online verification.

## Claims suitable for the revised article

The defensible contribution is the **specific experimental characterization**:

1. A complete, word-and-offset-matched scan of the 64 shared nonce bits,
   including an independently confirmed aggregate Salsa20/2 contrast.
2. Emitted-output profiles, with feed-forward included, analyzed under the
   same nonce inputs and matched random-function controls.
3. An intervention that holds every measured HW value and the DC share fixed
   while disrupting repeated block alignment, thereby quantifying the role
   of order in the AC statistic.

These claims neither require nor establish that incomplete two-round
diffusion, input-word asymmetry, or a block-related period was previously
unknown. A useful explanation derived from the round schedule would connect
these measurements to the construction without claiming to discover the
schedule's mathematical dependencies.

## Outstanding source work before making a priority claim

The following checks remain open and should not be reported as completed:

- Read Bernstein's original ChaCha paper, including its discussion of Salsa
  diffusion and the motivation for changing the round function.
- Read the Salsa20 specification and the cited 2008 Salsa20-family chapter;
  separate properties of the permutation from emitted output after
  feed-forward.
- Read the foundational work by Aumasson and coauthors on differential
  analysis of Salsa, ChaCha, and Rumba, then follow its citations in the
  PNB-based literature. Confirm the exact metadata before adding a record.
- Reopen Ghafoori et al. (existing DOI
  `10.1587/transinf.2022icp0015`) and compare the exact input words, output
  observables, and round conventions with this experiment.
- Search subsequent work through the submission date for block-position HW
  profiles, nonce-word asymmetry, and diffusion measurements under different
  output groupings. A lack of results in a narrow search would still not be
  proof of first occurrence.

The present table is intended to make the scope assessable now while avoiding
unsupported first-ever language. It should not be described in submission
materials as a comprehensive or freshly verified literature review.
