30 October 2026

Dear Editors of Electronics,

Please consider “Block-Position Structure in Reduced ChaCha20 and Salsa20: Experimental Diagnostics of IV Diffusion” for publication as an Article in Electronics.

The manuscript connects three stages of a nonce response: the round function, the feed-forward that forms the emitted block, and the measurement applied to it. Dependency analysis explains missing Salsa20 responses; paired finalization interventions isolate the contribution of modular addition; rotation and resolution controls distinguish these construction effects from aggregation effects.

A prospective experiment on 80 new key pairs shows that the Salsa20/2 nonce-word entropy gap remains without feed-forward at 0.72940 bits and increases by 0.05865 bits under modular addition. Mixed nonce derivatives identify an interaction predicted by conditional carry identities. The corresponding planned ChaCha20 entropy-gap change at 128-bit resolution remains unresolved (p = 0.108). These results characterize reduced-core diffusion without claiming a key-recovery attack, a full-round weakness, or superior detector sensitivity.

The focused literature review relates the work to diffusion diagnostics and differential cryptanalysis through October 2026. A separate, self-contained supplement preserves the complementary cipher studies and detailed tables. The reviewer archive contains fixed protocols, raw data, code, and independent numerical audits; planned tests and descriptive analyses are distinguished throughout. Public deposition is pending, as stated in the manuscript.

Sincerely,

Paweł Augustynowicz  
Faculty of Cybernetics, Military University of Technology  
Warsaw, Poland  
pawel.augustynowicz@wat.edu.pl

---

Draft for author review. Before using the letter, confirm the manuscript's publication and concurrent-submission status and add any declarations required by the current journal instructions. These statements have not been inferred on the author's behalf.
